
package logica;

import igu.Torneo;

public class Proyecto {

   
    public static void main(String[] args) {
        Torneo tor = new Torneo(); 
        tor.setVisible(true);
        tor.setLocationRelativeTo(null);
    }
    
}
